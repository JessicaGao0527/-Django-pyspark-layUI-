import csv
import datetime
from myapp.models import Dataset
from pyspark.sql import SparkSession
from pyspark.ml.linalg import Vectors
import pyspark.sql.types as DataTypes
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.clustering import KMeans
from pyspark.ml.classification import NaiveBayes, NaiveBayesModel, LogisticRegression
from pyspark.mllib.util import MLUtils
from pyspark.sql import functions as F
import pandas as pd

spark = SparkSession.builder.appName('data_analysis').master('local').getOrCreate()

def read_dataset_title(user_id, dataset_id):
    '''
    :param user_id:
    :param dataset_id:
    :return: all columns in the chosen dataset
    '''
    user_id = int(user_id)
    dataset_id = int(dataset_id)
    dataset_title = Dataset.objects.get(id=dataset_id).title
    dataset_path = './dataset/'+str(user_id)+'/'+dataset_title
    # spark = SparkSession.builder.appName('data_analysis').master('local').getOrCreate()
    # dataset = spark.read.csv(dataset_path, header=True)
    with open(dataset_path, 'r') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            dataset_title = row
            break
    index = 0
    for i,title in enumerate(dataset_title):
        if title == '':
            title = 'Unnamed_' + str(index)
            index = index + 1
            dataset_title[i] = title
    # dataset.printSchema()
    return dataset_title


def get_all_line(user_id, dataset_id):
    '''

    :param user_id:
    :param dataset_id:
    :return: all lines in a list
    '''
    # user_id = int(user_id)
    # dataset_title = Dataset.objects.get(id=dataset_id).title
    # dataset_path = './dataset/' + str(user_id) + '/' + dataset_title
    # spark = SparkSession.builder.appName('data_analysis').master('local').getOrCreate()
    # df = pd.read_csv(dataset_path)
    # df = spark.createDataFrame(df)
    # unnameIndex = 0
    # for col in df.columns:
    #     if col.startswith("Unnamed: "):
    #         df = df.withColumnRenamed('Unnamed: ' + str(unnameIndex), "Unnamed_" + str(unnameIndex))
    #         unnameIndex = unnameIndex + 1
    df = read_dataframe(user_id, dataset_id)
    df_title = df.columns
    df_list = df.toPandas().values.tolist()
    df_list_transformed = []
    for singleList in df_list:
        tempDic = {}
        for index, col in enumerate(df_title):
            tempDic[col]=singleList[index]
        df_list_transformed.append(tempDic)
    return df_list_transformed


def get_summary(user_id, dataset_id):
    '''
    :param user_id:
    :param dataset_id:
    :return: summary in a list
    '''
    # user_id = int(user_id)
    # dataset_title = Dataset.objects.get(id=dataset_id).title
    # dataset_path = './dataset/' + str(user_id) + '/' + dataset_title
    # spark = SparkSession.builder.appName('data_analysis').master('local').getOrCreate()
    # df_origin = pd.read_csv(dataset_path)
    # df_origin = spark.createDataFrame(df_origin)
    # unnameIndex = 0
    # for col in df_origin.columns:
    #     if col.startswith("Unnamed: "):
    #         df_origin = df_origin.withColumnRenamed('Unnamed: ' + str(unnameIndex), "Unnamed_" + str(unnameIndex))
    #         unnameIndex = unnameIndex + 1
    df_origin = read_dataframe(user_id, dataset_id)
    df = df_origin.summary()
    attrs = []
    for attr in df.select("summary").toPandas().values.tolist():
        attrs.append(attr[0])
    cols = df.columns
    cols.remove('summary')
    nullCount = []
    for col in cols:
        nullCount.append(df_origin.filter(col+' is null').count())
    lists = df.toPandas().values.tolist()
    df_list_transformed = []
    for singleList in lists:
        tempDic = {}
        tempDic["function"] = singleList[0]
        for index, col in enumerate(cols):
            tempDic[col] = singleList[index + 1]
        df_list_transformed.append(tempDic)
    tempDic = {}
    tempDic["function"] = "EmptyNum"
    for index, col in enumerate(cols):
        tempDic[col] = nullCount[index]
    df_list_transformed.append(tempDic)
    return df_list_transformed


def preTreatment(user_id, dataset_id):
    pass


def addChart(user_id, dataset_id, aggDic, applyCols, groupBy=None ):
    # user_id = int(user_id)
    # dataset_id = int(dataset_id)
    # dataset_title = Dataset.objects.get(id=dataset_id).title
    # dataset_path = './dataset/' + str(user_id) + '/' + dataset_title
    # spark = SparkSession.builder.appName('data_analysis').master('local').getOrCreate()
    # df = pd.read_csv(dataset_path)
    # df = spark.createDataFrame(df)
    # unnameIndex = 0
    df = read_dataframe(user_id, dataset_id)
    for col in df.columns:
        if col.startswith("Unnamed: "):
            df = df.withColumnRenamed('Unnamed: ' + str(unnameIndex), "Unnamed_" + str(unnameIndex))
            unnameIndex = unnameIndex + 1
    labels = []
    datasets = []
    data = []
    if groupBy:
        result = df.groupBy(groupBy).agg(aggDic).toPandas().values.tolist()
        for item in result:
            labels.append(item[0])
            tempData = []
            for index, col in enumerate(applyCols):
                tempData.append(item[index+1])
            datasets.append(tempData)
        return labels, datasets
    else:
        result = df.agg(aggDic).toPandas().values.tolist()
        labels = applyCols
        for item in result:
            # for index, col in enumerate(applyCols):
            #     labels.append(col)
            #     data.append(item[index])
            datasets.append(item)
        return labels, datasets




def logisticRegression(dataset):
    pass


def KMeansProcess(user_id, dataset_id, typeList, features, groupByCol):
    user_id = int(user_id)
    dataset_id = int(dataset_id)
    dataset_title = Dataset.objects.get(id=dataset_id).title
    dataset_path = './dataset/' + str(user_id) + '/' + dataset_title
    spark = SparkSession.builder.appName('data_analysis').master('local').getOrCreate()
    # df = spark.read.csv(dataset_path, header=True)
    df = pd.read_csv(dataset_path)
    df = spark.createDataFrame(df)
    unnameIndex = 0
    for col in df.columns:
        if col.startswith("Unnamed: "):
            df = df.withColumnRenamed('Unnamed: ' + str(unnameIndex), "Unnamed_" + str(unnameIndex))
            unnameIndex = unnameIndex + 1
    for index, type in enumerate(typeList):
        dic = {0: "String", 1: "int", 2: "float", 3: "double"}
        typeList[index] = dic[type]
    cols = df.columns
    for index, col in enumerate(cols):
        df = df.withColumn(col, df[col].astype(typeList[index]))
    df.printSchema()
    vec_assembler = VectorAssembler(inputCols=features, outputCol="features")
    df = vec_assembler.transform(df)
    kmean = KMeans()
    model = kmean.fit(df)
    transformed = model.transform(df).select("prediction")


def read_dataframe(user_id, dataset_id):
    user_id = int(user_id)
    dataset_id = int(dataset_id)
    csvType = '.csv'
    txtType = '.txt'
    sqlType = '.sqlite3'
    dataset_title = Dataset.objects.get(id=dataset_id).title
    dataset_path = './dataset/' + str(user_id) + '/' + dataset_title
    spark = SparkSession.builder.appName('data_analysis').master('local').getOrCreate()
    df = None
    dataset = Dataset.objects.get(id=dataset_id)
    df = pd.read_csv(dataset.path)

    df = spark.createDataFrame(df)
    unnameIndex = 0
    for col in df.columns:
        if col.startswith("Unnamed: "):
            df = df.withColumnRenamed('Unnamed: ' + str(unnameIndex), "Unnamed_" + str(unnameIndex))
            unnameIndex = unnameIndex + 1
    return df




