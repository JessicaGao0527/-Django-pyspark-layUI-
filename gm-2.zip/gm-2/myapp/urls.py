# 引入path
from django.urls import path
from . import views

# 正在部署的应用的名称
app_name = 'myapp'

urlpatterns = [
    # path函数将url映射到视图
    path('article-list/', views.article_list, name='article_list'),
    # 一条数据分析记录的详情
    path('article-detail/<int:id>/', views.article_detail, name='article_detail'),
    # 上传数据页面
    path('article-create/', views.article_create, name='article_create'),
    # 安全删除记录
    path(
        'article-safe-delete/<int:id>/',
        views.article_safe_delete,
        name='article_safe_delete'
    ),
    path('data/<int:id>/', views.response_data, name='response_data'),
    path('k/<int:id>/', views.k, name='k'),
    # 一定要加斜杠
    path('table/<int:id>/', views.table, name='table'),
    path('basic-info/<int:id>', views.basic_info, name='basic_info'),
    path('addChart/<int:dataset_id>', views.add_chart, name="add_chart"),
    path('addChartForm/<int:dataset_id>/', views.add_chart_form, name="add_chart_form"),
    path('detail/<int:dataset_id>/', views.detail, name='dataset_detail'),

    # path('kmeans_detail/<int:id>/', views.kmeans_detail, name='kmeans_detail')
    # path('info/<int:id>/', views.info, name='info')
    # path('result/<int:id>/', views.result, name='result')
]