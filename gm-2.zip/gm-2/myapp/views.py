import csv
import json

from django.core.mail.backends import console
from django.shortcuts import render

# Create your views here.

# 导入 HttpResponse 模块
from django.http import HttpResponse, JsonResponse

from django.shortcuts import render
# import markdown
from django.template import loader
from django.views.decorators.clickjacking import xframe_options_exempt
from pyspark.ml.evaluation import MulticlassClassificationEvaluator

from myapp import data_process
from .models import *
from .forms import *

from django.contrib.auth.decorators import login_required

# 引入redirect重定向模块
from django.shortcuts import render, redirect
# 引入HttpResponse
from django.http import HttpResponse
# 引入刚才定义的ArticlePostForm表单类
from .forms import ArticlePostForm
# 引入User模型
from django.contrib.auth.models import User
import os
from . import data_process_old
import pyspark
from pyspark.sql import SparkSession
import pandas as pd
import itertools
from pyspark.sql import SparkSession
from pyspark.ml.feature import StringIndexer
from pyspark.sql import Row
from pyspark.ml.clustering import KMeans
# 如果您的Spark> 2.x导入 org.apache.spark.ml.linalg.Vector,并不是org.apache.spark.mllib.linalg.Vector
from pyspark.ml.linalg import Vectors
import numpy as np
from . import data_process


# def article_list(request):
#     # 取出所有博客文章
#     articles = ArticlePost.objects.all()
#     # 需要传递给模板（templates）的对象
#     context = { 'articles': articles }
#     # render函数：载入模板，并返回context对象
#     return render(request, 'article/list.html', context)


@login_required(login_url='/userprofile/login')
def article_list(request):
    datasets = Dataset.objects.filter(user_id=request.user.id)
    context ={"datasets":datasets}
    return render(request, 'article/list.html', context)



# 文章详情
# def article_detail(request, id):
#     # 取出相应的文章
#     article = ArticlePost.objects.get(id=id)
#     # 需要传递给模板的对象
#     context = { 'article': article }
#     # 载入模板，并返回context对象
#     return render(request, 'article/detail.html', context)


# @login_required(login_url='/userprofile/login')
# def data(request,id):
#     id = request.post.get("id")
#     gm = [{"1":"1", "2" : "2"}, {"1": "3", "2":"4"}]
#     resultdict = {}
#     resultdict['code'] = 0
#     resultdict['msg'] = ""
#     resultdict['count'] = len(gm)
#     resultdict['data'] = gm
#
#     return JsonResponse(resultdict, safe=False)

def response_data(request, id):
    # 通过前端传来的文章id取出数据集对象
    dataset = Dataset.objects.get(id=id)
    # 调用dataframe的describe方法对数据集进行描述
    df = pd.read_csv(dataset.path).describe()
    gm = pd.read_csv(dataset.path)
    dic = []
    for idx in df.columns:
        dd = {}
        keys = df.index.values.tolist()
        values = df[idx].values.tolist()
        for k, v in zip(keys, values):
            dd[k] = v
        dic.append(dd)

    # 记录属性的名字以及统计空值个数
    for dd, name in zip(dic, df.columns.values):
        dd['name'] = name
        dd['ISNULL'] = int(gm[name].isnull().sum())

    # 将结果处理成字典形式，和前端对应的数据接口对应
    data = {"code": 0, "msg": "", "count": 1000, "data":dic}
    # 将字典处理成Json格式返回
    return HttpResponse(json.dumps(data), content_type="application/json")


@login_required(login_url='/userprofile/login')
def basic_info(request, id):
    dataset = Dataset.objects.get(id=id)
    context = {"dataset": dataset}
    return render(request, "article/detail.html", context)

@login_required(login_url='/userprofile/login')
def article_detail(request, id):
    # 通过前端传来的数据集id在Dataset表中取出对应的数据集对象
    dataset = Dataset.objects.get(id=id)
    # 以键值对形式封装进dict中
    context = {"dataset" : dataset}
    # 通过render传回前端，并利用context中的内容渲染html页面
    return render(request, "article/basic_info.html", context)



# 上传文件的视图
# 检查登录
@login_required(login_url='/userprofile/login')
def article_create(request):
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    user_id = request.user.id
    if request.method == "POST":  # 请求方法为POST时，进行处理
        myFile = request.FILES.get("dataset", None)  # 获取上传的文件，如果没有文件，则默认为None
        if not myFile:
            return HttpResponse("no files for upload!")
        # 不同操作系统的路径斜杠方向可能不同
        path = BASE_DIR + '/dataset/'+ str(user_id)+ '/'
        if not os.path.exists(path):
            os.mkdir(path)
        if os.path.exists(path+myFile.name):
            os.remove(path+myFile.name)
            old_set = Dataset.objects.get(title=myFile.name)
            old_set.delete()
        dataset_form = DatasetForm(data=request.POST)
        if dataset_form.is_valid():
            dataset = dataset_form.save(commit=False)
            dataset.title = myFile.name
            dataset.user = User.objects.get(id=user_id)
            dataset.path = path+myFile.name
            dataset.type = int(request.POST["type"])
            dataset.save()
        destination = open(os.path.join(path, myFile.name), 'wb+')  # 打开特定的文件进行二进制的写操作
        for chunk in myFile.chunks():  # 分块写入文件
            destination.write(chunk)
        destination.close()

        return HttpResponse("upload Completed!")
    elif request.method == "GET":
        context = {}
        return render(request, 'article/create.html', context)
    else:
        return HttpResponse("Only POST or GET")


# @login_required(login_url='/userprofile/login/')
# def article_create(request):
#     # 判断用户是否提交数据
#     if request.method == "POST":
#         # 将提交的数据赋值到表单实例中
#         article_post_form = ArticlePostForm(data=request.POST)
#         # 判断提交的数据是否满足模型的要求
#         if article_post_form.is_valid():
#             # 保存数据，但暂时不提交到数据库中
#             new_article = article_post_form.save(commit=False)
#             # 指定目前登录的用户为作者
#             new_article.author = User.objects.get(id=request.user.id)
#             # 将新文章保存到数据库中
#             new_article.save()
#             # 完成后返回到文章列表
#             return redirect("myapp:article_list")
#         # 如果数据不合法，返回错误信息
#         else:
#             return HttpResponse("表单内容有误，请重新填写。")
#     # 如果用户请求获取数据
#     else:
#         # 创建表单类实例
#         article_post_form = ArticlePostForm()
#         # 赋值上下文
#         context = { 'article_post_form': article_post_form }
#         # 返回模板
#         return render(request, 'article/create.html', context)


# 安全删除记录
# @login_required(login_url='/userprofile/login/')
def article_safe_delete(request, id):
    # 为什么一定要规定Post?
    if request.method == 'POST':
        dataset = Dataset.objects.get(id=id)
        dataset.delete()
        return redirect("myapp:article_list")
    else:
        return HttpResponse("仅允许post请求")

@login_required(login_url='/userprofile/login')
def k(request, id):
    # 根据数据集id取出dataset对象
    dataset = Dataset.objects.get(id=id)
    # 通过spark读入
    spark = SparkSession.builder.appName('data_analysis').master('local').getOrCreate()
    df = spark.read.format('csv') \
        .option('header', 'true') \
        .option('inferSchema', 'true') \
        .load(dataset.path)
    # 将用户选定的label一列重新编码
    feature = StringIndexer(inputCol=request.POST["inputCol"], outputCol="categoryIndex")
    target = feature.fit(df).transform(df)
    # 把特征对应的若干列转化成稠密向量
    gm = request.POST['features'].split(',')
    def transData(row):
        fe = [row[str] for str in gm]

        return Row(label=row["categoryIndex"],
                   features=Vectors.dense(fe))

    # 转化成Dataframe格式
    transformed = target.rdd.map(transData).toDF()
    kmeans = KMeans(k=int(request.POST["k"]))
    # 进行kmeans拟合
    model = kmeans.fit(transformed)
    # 取得结果
    result = model.transform(transformed)

    tmp = result.select(result.prediction.cast('double'), result.label)
    # 根据不同指标构建若干个评估器
    evaluator_acc = MulticlassClassificationEvaluator(predictionCol="prediction", metricName="accuracy")
    evaluator_f1 = MulticlassClassificationEvaluator(predictionCol="prediction", metricName="f1")
    evaluator_pre = MulticlassClassificationEvaluator(predictionCol="prediction", metricName="weightedPrecision")
    evaluator_recall = MulticlassClassificationEvaluator(predictionCol="prediction", metricName="weightedRecall")
    # 计算指标
    acc = evaluator_acc.evaluate(tmp)
    f1 = evaluator_f1.evaluate(tmp)
    pre = evaluator_pre.evaluate(tmp)
    recall = evaluator_recall.evaluate(tmp)
    # 将原始数据集+预测结果整合成一个csv
    dd = pd.read_csv(dataset.path)
    dd['prediction'] = result.select("prediction").toPandas()
    # 将整合后的csv化为list
    table = np.array(dd).tolist()
    index = ["Accuarycy", "F1 score", "Precision", "Recall"]
    value = [acc, f1, pre, recall]
    # 将预测结果，评估指标打包进字典返回
    context = {"cols": dd.columns.values, 'dataset': dataset, "id": id, 'cnts':[i for i in range(2,len(dd.columns.values))] \
               ,"rows": table \
               ,"index":index \
               ,"values":value
               ,"dataset":dataset
                }

    return render(request, 'article/result.html', context)


@login_required(login_url='/userprofile/login')
def table(request, id):
    dataset = Dataset.objects.get(id=id)

    df = pd.read_csv(dataset.path)
    with open(dataset.path, 'r') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            dataset_title = row
            break
    index = 0
    for i,title in enumerate(dataset_title):
        if title == '':
            title = 'Unnamed_' + str(index)
            index = index + 1
            dataset_title[i] = title

    context = {"cols": dataset_title, 'dataset': dataset, "id": id, 'cnts':[i for i in range(2,len(df.columns.values))] \
               ,"colnames":df.columns.values \
               ,"rows": []}

    return render(request, 'article/kmeans.html', context)
    # return render(request, 'article/result.html', context)


@login_required(login_url='/userprofile/login')
def info(request, id):
    dataset = Dataset.objects.get(id=id)
    df = pd.read_csv(dataset.path)
    with open(dataset.path, 'r') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            dataset_title = row
            break
    index = 0
    for i,title in enumerate(dataset_title):
        if title == '':
            title = 'Unnamed_' + str(index)
            index = index + 1
            dataset_title[i] = title


    context = {"cols": dataset_title, 'dataset_id': id, "id": id}
    # context = {"id": id}
    return render(request, "article/kmeans.html", context)
    # return HttpResponse(json.dumps(context), content_type="application/json")

@xframe_options_exempt
def add_chart(request, dataset_id):
    if request.method == 'POST':
        postDataDic = request.POST
        loopCounterDic = {}
        applyCols = []
        # groupByList = []
        groupBy = None
        dataset_name = Dataset.objects.get(id=dataset_id).title
        try:
            groupBy = postDataDic["groupBy"]
        except:
            pass
        dataset_col = data_process.read_dataset_title(request.user.id, dataset_id)
        for colId, col in enumerate(dataset_col):
            loopCounterDic[str(colId + 1)] = col
            # groupByThis = None
            applyOnThis = None
            # try:
            #     groupByThis = postDataDic["groupBy_"+col]
            # except Exception as e:
            #     pass
            try:
                applyOnThis = postDataDic["applyOn_"+col]
            except Exception as e:
                pass
            if(applyOnThis):
                applyCols.append(applyOnThis)
            # if(groupByThis):
            #     groupByList.append(groupByThis)
        if not len(applyCols):
            return HttpResponse("至少选择一列应用函数！")
        func = postDataDic["function"]
        type = postDataDic["type"]
        aggDic = {}
        for apply_col in applyCols:
            aggDic[apply_col] = func
        labels, data = data_process.addChart(request.user.id, dataset_id, aggDic, applyCols, groupBy)
        if groupBy:
            reversed_apply_cols = []
            for i in range(len(labels)):
                for col in labels:
                    reversed_apply_cols.append(col)
            reversed_apply_cols.reverse()

        else:
            reversed_apply_cols = []
            reversed_apply_cols.append(func)
        context = {"cols": dataset_col, 'dataset_id': dataset_id, "type": type, "labels": applyCols, "data": data, "dataset_name": dataset_name, "function": func, "apply_cols": reversed_apply_cols}
        return render(request, "article/chart.html", context)
    else:
        return HttpResponse("请使用POST")


@xframe_options_exempt
def add_chart_form(request, dataset_id):
    dataset = Dataset.objects.get(id=dataset_id)
    dataset_col = data_process.read_dataset_title(request.user.id, dataset_id)
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    path = BASE_DIR + '\\dataset\\' + str(request.user.id) + '\\details_' + str(dataset_id) + '.txt'
    context = {"cols": dataset_col, 'dataset_id': dataset_id,'dataset':dataset}
    return render(request, "article/addChart.html", context)


@login_required(login_url='/userprofile/login')
def detail(request, dataset_id):
    dataset_col = data_process.read_dataset_title(request.user.id, dataset_id)
    datasets = Dataset.objects.filter(user_id=request.user.id)
    dataset = Dataset.objects.get(id=dataset_id)
    context = {"datasets": datasets, "dataset_col": dataset_col, "dataset_id":dataset.id, "addchart":'自定义图表', "have_details": dataset.have_details, "analysis": "KMeans"}
    return render(request, "myapp/detail_new.html", context)